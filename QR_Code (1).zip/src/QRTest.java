import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class QRTest {

	@Test
	void test() {
		System.out.println("This is the testcase in this class");
        String str1="This is the testcase in this class";
        assertEquals("This is the testcase in this class", str1);
	}

}
